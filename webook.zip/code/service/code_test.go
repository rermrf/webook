package service

import (
	"testing"
)

func TestCodeServiceImpl_Send(t *testing.T) {
	//testCases := []struct {
	//	name string
	//}{
	//	{},
	//}
}
