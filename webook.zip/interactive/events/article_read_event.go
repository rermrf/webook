package events

// ReadEvent 与article中一致
type ReadEvent struct {
	Uid int64
	Aid int64
}
