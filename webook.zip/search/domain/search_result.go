package domain

type SearchResult struct {
	Users    []User
	Articles []Article
}
