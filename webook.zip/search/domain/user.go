package domain

type User struct {
	Id       int64
	Email    string
	Nickname string
	Phone    string
}
