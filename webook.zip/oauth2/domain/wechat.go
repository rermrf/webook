package domain

type WechatInfo struct {
	OpenId  string `json:"openid"`
	UnionId string `json:"unionid"`
}
