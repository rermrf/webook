package connpool

type ShardingPool struct {
}
