package saramax

type Consumer interface {
	Start() error
}
